class Node(object):
    def __init__(self, identifier):
        pass

    def __str__(self):
        return self.__class__.__name__ +'(\n\t'+str(vars(self))+'\n)'

    __repr__ = __str__

class Root(Node):
    def __init__(self, identifier, children):
        pass


class Form(Node):
    def __init__(self, name, block):
        self.name = name
        self.block = block


class Statement(Node):
    pass


class Expression(Node):
    pass


class Block(Node):
    def __init__(self, statements):
        self.statements = statements


class Question(Statement):
    def __init__(self, variable, label):
        self.variable = variable
        self.label = label


class ifThen(Statement):
    def __init__(self, condition, children):
        pass
