from .base_nodes import *
from .field_types import *
'''
1.  If the current token is a '(', add a new node as the left child of the
    current node, and descend to the left child.

2.  If the current token is in the list ['+','-','/','*'], set the root value
    of the current node to the operator represented by the current token.
    Add a new node as the right child of the current node and descend to
    the right child.

3.  If the current token is a number, set the root value of the current node
    to the number and return to the parent.

4.  If the current token is a ')', go to the parent of the current node.
'''


'''
https://www.codingunit.com/unary-and-binary-operator-table
'''
class BinaryOperation(Node):
    def __init__(self, left_operand, right_operand):
        self.left_operand = left_operand
        self.right_operand = right_operand

class UnaryOperation(Node):
    def __init__(self, operand):
        self.operand = operand

# Binary Operations
class Inequality(BinaryOperation):
    pass

class LogicalAnd(BinaryOperation):
    pass

class Multiplication(BinaryOperation):
    pass

class Addition(BinaryOperation):
    pass

class Substraction(BinaryOperation):
    pass

class Division(BinaryOperation):
    pass

class LessThan(BinaryOperation):
    pass

class LessThanEquals(BinaryOperation):
    pass

class Assignment(BinaryOperation):
    pass

class Equality(BinaryOperation):
    pass

class GreaterThan(BinaryOperation):
    pass

class GreaterThanEquals(BinaryOperation):
    pass

class LogicalOr(BinaryOperation):
    pass

# Unary Operations
class LogicalNot(UnaryOperation):
    pass

class UnaryPlus(UnaryOperation):
    pass

class UnaryNegation(UnaryOperation):
    pass

class Variable(Node):
    def __init__(self, variable, datatype):
        self.variable = variable
        self.datatype = datatype


class Variable1(Node):
    def __init__(self, name):
        Node.__init__(self, "variable")
        self.name = name
        self._value = Undefined()

    def __str__(self):
        return "{}".format(self._value)

    def eval(self):
        return self._value

    def __add__(self, other):
        return self.eval() + other.eval()

    def __sub__(self, other):
        return self.eval() - other.eval()

    def __mul__(self, other):
        return self.eval() * other.eval()

    def __truediv__(self, other):
        return self.eval() / other.eval()

    def __or__(self, other):
        return (self.eval() | other.eval())

    def __and__(self, other):
        return (self.eval() & other.eval())

    def __invert__(self):
        return ~self.eval()

    def __lt__(self, other):
        return self.eval() < other.eval()

    def __gt__(self, other):
        return self.eval() > other.eval()

    def __ge__(self, other):
        return self.eval() >= other.eval()

    def ___le__(self, other):
        return self.eval() <= other.eval()

    def __ne__(self, other):
        return self.eval() != other.eval()

    def __eq__(self, other):
        return self.eval() == other.eval()
