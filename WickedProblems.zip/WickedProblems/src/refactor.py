from pyparsing import *
from ast.ast import *
from ast.base_nodes import *
from ast.field_types import *

def binary_node(node):
    def makeNode(_, __, tokens):
        print _,__,tokens
        return node(*tokens[0])
    return makeNode

class QL:
    # Booleans
    literal_and = Literal('&&').suppress()
   
    literal_or = Literal('||').suppress()
    # Unary
    literal_not = Literal('!').suppress()

    # Comparisons
    literal_greater_than = Literal('>').suppress()
    literal_less_than = Literal('<').suppress()
    literal_greater_than_equal = Literal('>=').suppress()
    literal_less_than_equal = Literal('<=').suppress()
    literal_equal = Literal('=').suppress()

    literall_not_equal = Literal('!=').suppress()
    # Basic Arithmics
    literal_addition = Literal('+').suppress()

    literal_substraction = Literal('-').suppress()

    literal_multiplication = Literal('*').suppress()

    literal_division = Literal('/').suppress()


    # Defines
    literal_if = Literal('if')
    colon = Literal(':').suppress()
    left_curly = Literal('{').suppress()
    right_curly = Literal('}').suppress()
    left_parenthesis = Literal('(').suppress()
    right_parenthesis = Literal(')').suppress()
    form_type = oneOf('form')
    field_boolean = Literal('boolean').addParseAction(lambda : Boolean)
    field_string = Literal('string').addParseAction(lambda: String)
    field_integer = Literal('integer').addParseAction(lambda: Integer)
    field_data = Literal('data').addParseAction(lambda: Data)
    field_decimal = Literal('decimal').addParseAction(lambda: Decimal)
    field_money = Literal('money').addParseAction(lambda: Money)
    field_type = field_boolean | field_string | field_integer | field_data | \
                field_decimal | field_money
    word = Word(alphas)
    # identifier = word.setResultsName("identifier")
    # identifier.addParseAction(lambda identifier : Variable(*identifier))

    
    numbers = Word(nums).addParseAction(lambda string, location, tokens : Integer(*tokens))


    boolean_precedence = [(literal_and, 2, opAssoc.LEFT, binary_node(LogicalAnd)),
                          (literal_or, 2, opAssoc.LEFT, binary_node(LogicalAnd)),
                          (literal_not, 1, opAssoc.RIGHT, binary_node(LogicalAnd))] 
                          
    # Unary
    comparison_precedence = [(literal_greater_than, 2, opAssoc.LEFT,
                              binary_node(GreaterThan)),
                             (literal_less_than, 2, opAssoc.LEFT,
                              binary_node(LessThan)),
                             (literal_greater_than_equal, 2, opAssoc.LEFT,
                              binary_node(GreaterThanEquals)),
                             (literal_less_than_equal, 2, opAssoc.LEFT,
                              binary_node(LessThanEquals)),
                             (literal_equal, 2, opAssoc.LEFT,
                              binary_node(Equality)),
                             (literall_not_equal, 2, opAssoc.LEFT,
                              binary_node(Equality))]

    arithmic_precedence = [(literal_addition, 2, opAssoc.LEFT,
                            binary_node(Addition)),
                           (literal_substraction, 2, opAssoc.LEFT,
                            binary_node(Substraction)),
                           (literal_multiplication, 2, opAssoc.LEFT,
                            binary_node(Multiplication)),
                           (literal_division, 2, opAssoc.LEFT,
                            binary_node(Division))]

    boolean_expression = operatorPrecedence(numbers,boolean_precedence)
    # boolean_expression.addParseAction(lambda child : \
            # Expression(child))

    comparison_expression = operatorPrecedence(numbers,comparison_precedence)
    arithmic_expression = operatorPrecedence(numbers,arithmic_precedence)

    expression =   Or(arithmic_expression | comparison_expression | boolean_expression)

    string = QuotedString('"')
    string.setResultsName("text")
    string.addParseAction(lambda _, __, tokens : String(**tokens.asDict()))


    label = QuotedString('"').addParseAction(lambda _, __, tokens : String(**tokens.asDict()))


    # form content
    question = label('value') + Group(Word(alphanums)('name') + Suppress(colon) + field_type('datatype'))('variable')
    question.addParseAction(lambda string, location, tokens : Question(**tokens.asDict()))

    # statement = string + identifier + Suppress(colon) + field_type + \
    #             Suppress("=") + arithmic_expression
    # statement.addParseAction(lambda content : Statement(*content))



    # conditional = Suppress(literal_if) + boolean_expression + evaluated
    # conditional.addParseAction(lambda content : Conditional(*content))


    # form items


    # outer form
    # form = Suppress(form_type) + Word(alphanums).suppress() + Suppress(left_curly) + form_item + Suppress(right_curly)


print(QL().expression.parseString('1+(5+3)'))